package com.example.sohbetuygulamasi;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class KayitOlActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_kayit_ol);
    }
}